package store_products;

public class Console implements Product {
    private String name;
    private double price;

    public Console(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getType() {
        return "Console";
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }
}
