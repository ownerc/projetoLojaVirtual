package store_products;

public class Tablet implements Product {
    private String name;
    private double price;

    public Tablet(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getType() {
        return "Tablet";
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }
}
