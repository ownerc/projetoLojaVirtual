package store_products;

public class Book implements Product {
    private String title;
    private String author;
    private String genre;
    private int year;
    private double price;

    public Book(String title, String author, String genre, int year, double price) {
        this.title = title;
        this.author = author;
        this.genre = genre;
        this.year = year;
        this.price = price;
    }

    public String getType() {
        return "Livro";
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public String getGenre() {
        return genre;
    }

    public int getYear() {
        return year;
    }
}
