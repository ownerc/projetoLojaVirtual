package store_products;

public class Computer implements Product {
    private String name;
    private double price;

    public Computer(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getType() {
        return "Computador";
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }
}
