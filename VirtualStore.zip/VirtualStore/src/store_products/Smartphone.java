package store_products;

public class Smartphone implements Product {
    private String name;
    private double price;

    public Smartphone(String name, double price) {
        this.name = name;
        this.price = price;
    }

    public String getType() {
        return "Smartphone";
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return name;
    }
}
