package store_products;

public class Game implements Product {
    private String title;
    private String genre;
    private String platform;
    private int releaseYear;
    private double price;

    public Game(String title, String genre, String platform, int releaseYear, double price) {
        this.title = title;
        this.genre = genre;
        this.platform = platform;
        this.releaseYear = releaseYear;
        this.price = price;
    }

    public String getType() {
        return "Jogo";
    }

    public double getPrice() {
        return price;
    }

    public String getName() {
        return title;
    }

    public String getGenre() {
        return genre;
    }

    public String getPlatform() {
        return platform;
    }

    public int getReleaseYear() {
        return releaseYear;
    }
}
