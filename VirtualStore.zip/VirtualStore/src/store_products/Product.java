package store_products;

public interface Product {
    String getType();
    double getPrice();
    String getName();
}
