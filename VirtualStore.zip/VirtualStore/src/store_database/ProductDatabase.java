package store_database;

import store_products.*;
import java.util.ArrayList;

public class ProductDatabase {
    protected static ArrayList<Product> products = new ArrayList<>();

    static {
        loadProducts();
    }

    protected static void loadProducts() {
        products.add(new Book("1984", "George Orwell", "Distopia", 1949, 39.90));
        products.add(new Book("O Senhor dos Anéis", "J.R.R. Tolkien", "Fantasia", 1954, 89.90));
        products.add(new Book("Dom Casmurro", "Machado de Assis", "Romance", 1899, 25.00));
        products.add(new Book("Duna", "Frank Herbert", "Fantasia", 1965, 59.90));
        products.add(new Book("O Pequeno Príncipe", "Antoine de Saint-Exupéry", "Fábula", 1943, 19.90));

        products.add(new Game("The Last of Us", "Ação", "PlayStation", 2013, 149.90));
        products.add(new Game("Minecraft", "Sandbox", "Multiplataforma", 2011, 99.90));
        products.add(new Game("God of War", "Aventura", "PlayStation", 2018, 129.90));
        products.add(new Game("Diablo IV", "MMO RPG", "Multiplataforma", 2022, 199.90));
        products.add(new Game("Elden Ring", "RPG", "Multiplataforma", 2022, 249.90));

        products.add(new Smartphone("iPhone 15", 4999.00));
        products.add(new Smartphone("Samsung Galaxy S23", 4199.00));
        products.add(new Smartphone("Motorola Edge 40", 2999.00));
        products.add(new Smartphone("Xiaomi Redmi Note 12", 1499.00));
        products.add(new Smartphone("Asus ROG Phone 7", 5199.00));

        products.add(new Tablet("iPad Pro", 9999.00));
        products.add(new Tablet("Samsung Galaxy Tab S9", 4999.00));
        products.add(new Tablet("Lenovo Tab P11", 1999.00));
        products.add(new Tablet("Xiaomi Pad 6", 2599.00));
        products.add(new Tablet("Multilaser M10A", 999.00));

        products.add(new Console("PlayStation 5", 4499.00));
        products.add(new Console("Xbox Series X", 4299.00));
        products.add(new Console("Nintendo Switch", 2799.00));

        products.add(new Computer("Notebook Dell Inspiron", 3899.00));
        products.add(new Computer("Notebook Acer Aspire 5", 3299.00));
        products.add(new Computer("PC Gamer Intel i5", 4999.00));

        products.add(new Accessory("Fone JBL Tune 510BT", 249.00));
        products.add(new Accessory("Controle Xbox sem fio", 349.00));
        products.add(new Accessory("Capa iPhone 15", 99.00));
        products.add(new Accessory("Capa Galaxy S23", 89.00));
    }

    public static ArrayList<Product> getProducts() {
        return products;
    }
}
