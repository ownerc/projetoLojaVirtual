package store_cart;

import store_products.Product;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import java.util.List;

public class Cart {

    private List<Product> items = new ArrayList<>();

    public void addProduct(Product product) {
        items.add(product);
        JOptionPane.showMessageDialog(null, product.getName() + " foi adicionado ao carrinho.");
    }

    public void removeProduct(int index) {
        if (index >= 0 && index < items.size()) {
            items.remove(index);
            JOptionPane.showMessageDialog(null, "Produto removido do carrinho.");
        }
    }

    public List<Product> getItems() {
        return new ArrayList<>(items);
    }

    public double getTotalPrice() {
        double total = 0.0;
        for (Product p : items) {
            total += p.getPrice();
        }
        return total;
    }

    public boolean isEmpty() {
        return items.isEmpty();
    }

    public List<Product> getProductList() {
        return getItems();
    }

    public double getTotal() {
        return getTotalPrice(); // idem
    }

    public void clear() {
        items.clear();
    }

    public String getCartSummary() {
        if (items.isEmpty()) return "Seu carrinho está vazio.";

        StringBuilder summary = new StringBuilder("Produtos no carrinho:\n\n");
        for (int i = 0; i < items.size(); i++) {
            Product p = items.get(i);
            summary.append(i + 1).append(". ")
                    .append(p.getName()).append(" - ")
                    .append(p.getType()).append(" - R$")
                    .append(String.format("%.2f", p.getPrice())).append("\n");
        }
        summary.append("\nTotal: R$").append(String.format("%.2f", getTotalPrice()));
        return summary.toString();
    }
}
