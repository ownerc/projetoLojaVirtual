import produtos.Produtos;

public class Pedidos {
    private Produtos[] itens;
    private int quantidadeItens;
    private double totalPedido;

    public Pedidos(int tamanhoMaximo) {
        itens = new Produtos[tamanhoMaximo];
        quantidadeItens = 0;
        totalPedido = 0.0;
    }

    public void adicionarItem(Produtos produto) {
        if (quantidadeItens < itens.length) {
            itens[quantidadeItens] = produto;
            quantidadeItens++;
            totalPedido += getPreco(produto);
        } else {
            System.out.println("Seu carrinho está cheio!");
        }
    }

    public double fecharPedido() {
        return totalPedido;
    }

    private double getPreco(Produtos p) {
        if (p instanceof produtos.Livros) {
            return ((produtos.Livros) p).getPreco();
        } else if (p instanceof produtos.Jogos) {
            return ((produtos.Jogos) p).getPreco();
        }
        return 0.0;
    }
}
