package produtos;

public class Jogos implements Produtos {
    private String nome;
    private String codigo;
    private double preco;
    private String tipo;

    public double getPreco() {
        return preco;
    }

    public Jogos(String nome, String codigo, double preco, String tipo) {
        this.nome = nome;
        this.codigo = codigo;
        this.preco = preco;
        this.tipo = tipo;
    }

    @Override
    public void nome() {
        System.out.println("Nome do jogo: " + nome);
    }

    @Override
    public void codigo() {
        System.out.println("Código do jogo: " + codigo);
    }

    @Override
    public void preco() {
        System.out.println("Preço do jogo: R$ " + preco);
    }

    @Override
    public void exibirDetalhes() {
        System.out.println("Detalhes do Jogo: ");
        nome();
        codigo();
        preco();
        System.out.println("Tipo: " + tipo);
    }
}
