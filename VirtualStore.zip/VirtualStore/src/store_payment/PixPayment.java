package store_payment;

public class PixPayment extends PaymentMethod {
    public String getMethodName() {
        return "Pix";
    }
}
