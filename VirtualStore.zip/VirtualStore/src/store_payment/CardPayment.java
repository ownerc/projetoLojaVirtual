package store_payment;

public class CardPayment extends PaymentMethod {
    private String cardNumber;
    private String cardType;

    public CardPayment(String cardNumber, String cardType) {
        this.cardNumber = cardNumber;
        this.cardType = cardType;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public String getCardType() {
        return cardType;
    }

    public String getMethodName() {
        return "Cartão (" + cardType + ")";
    }
}
