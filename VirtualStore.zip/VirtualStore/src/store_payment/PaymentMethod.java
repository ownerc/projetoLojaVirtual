package store_payment;

public abstract class PaymentMethod {
    public abstract String getMethodName();
}
