package store_order;

import store_products.Product;
import java.util.List;
import java.util.Date;

public class Order {

    public enum Status {
        Pendente, Enviado, Recebido, Cancelado
    }

    private static int orderCounter = 1;
    private int orderId;
    private List<Product> products;
    private double total;
    private Date date;
    private Status status;

    public Order(List<Product> products, double total) {
        this.orderId = orderCounter++;
        this.products = products;
        this.total = total;
        this.date = new Date();
        this.status = Status.Pendente;
    }

    public int getOrderId() {
        return orderId;
    }

    public List<Product> getProducts() {
        return products;
    }

    public double getTotal() {
        return total;
    }

    public Date getDate() {
        return date;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status newStatus) {
        this.status = newStatus;
    }

    public String getOrderSummary() {
        StringBuilder sb = new StringBuilder();
        sb.append("Pedido #").append(orderId).append(" - ")
                .append(date).append(" - Status: ").append(status).append("\n")
                .append("Produtos:\n");

        for (Product p : products) {
            sb.append("- ").append(p.getName())
                    .append(" - R$").append(String.format("%.2f", p.getPrice()))
                    .append("\n");
        }

        sb.append("Total: R$").append(String.format("%.2f", total));
        return sb.toString();
    }
}
