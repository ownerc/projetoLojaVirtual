package store_users;

import store_payment.PaymentMethod;

public class User {
    private String name;
    private Address address;
    private String birthDate;
    private String cpf;
    private String phone;
    private PaymentMethod paymentMethod;
    private Responsible responsible;

    public User(String name, Address address, String birthDate, String cpf, String phone, PaymentMethod paymentMethod) {
        this.name = name;
        this.address = address;
        this.birthDate = birthDate;
        this.cpf = cpf;
        this.phone = phone;
        this.paymentMethod = paymentMethod;
    }

    public void setResponsible(Responsible responsible) {
        this.responsible = responsible;
    }

    public Responsible getResponsible() {
        return responsible;
    }

    public String getBirthDate() {
        return birthDate;
    }

    public String getName() {
        return name;
    }

    public String getCpf() {
        return cpf;
    }

    public String getPhone() {
        return phone;
    }

    public Address getAddress() {
        return address;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }
}
