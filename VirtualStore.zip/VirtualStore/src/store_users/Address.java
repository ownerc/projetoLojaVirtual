package store_users;

public class Address {
    private String state;
    private String city;
    private String neighborhood;
    private String street;

    public Address(String state, String city, String neighborhood, String street) {
        this.state = state;
        this.city = city;
        this.neighborhood = neighborhood;
        this.street = street;
    }

    public String getFullAddress() {
        return street + ", " + neighborhood + ", " + city + " - " + state;
    }
}
