package store_users;

public class Responsible {
    private String name;
    private String cpf;
    private String phone;
    private String birthDate;

    public Responsible(String name, String cpf, String phone, String birthDate) {
        this.name = name;
        this.cpf = cpf;
        this.phone = phone;
        this.birthDate = birthDate;
    }

    public String getName() {
        return name;
    }

    public String getCpf() {
        return cpf;
    }

    public String getPhone() {
        return phone;
    }

    public String getBirthDate() {
        return birthDate;
    }
}
