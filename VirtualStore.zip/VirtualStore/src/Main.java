import store_menu.StoreMainMenu;

public class Main {
    public static void main(String[] args) {
        StoreMainMenu menu = new StoreMainMenu();
        menu.openMenu();
    }
}
