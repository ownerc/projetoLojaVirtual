import java.util.Scanner;
import produtos.*;
import clientes.*;
import caixa.Caixa;

public class Main {
    public static void main(String[] args) {
        Scanner userInputs = new Scanner(System.in);
        Caixa caixa = new Caixa();

        Produtos[] catalogo = new Produtos[10];
        int produtosCadastrados = 0;

        Clientes[] clientes = new Clientes[10];
        int clientesCadastrados = 0;

        boolean executando = true;

        while (executando) {
            System.out.println("\n LOJA VIRTUAL");
            System.out.println("1 - Cadastrar produto");
            System.out.println("2 - Listar produtos");
            System.out.println("3 - Cadastrar cliente");
            System.out.println("4 - Listar clientes");
            System.out.println("5 - Realizar pedido");
            System.out.println("6 - Saldo do caixa");
            System.out.println("7 - Sair");
            System.out.print("Escolha: ");

            int opcao = userInputs.nextInt();
            userInputs.nextLine();

            switch (opcao) {
                case 1:
                    if (produtosCadastrados < catalogo.length) {
                        System.out.print("Livro ou Jogo (L/J)? ");
                        String tipo = userInputs.nextLine();

                        System.out.print("Nome: ");
                        String nome = userInputs.nextLine();
                        System.out.print("Código: ");
                        String codigo = userInputs.nextLine();
                        System.out.print("Preço: ");
                        double preco = userInputs.nextDouble();
                        userInputs.nextLine();

                        if (tipo.equalsIgnoreCase("L")) {
                            System.out.print("Autor: ");
                            String autor = userInputs.nextLine();
                            catalogo[produtosCadastrados++] = new Livros(nome, codigo, preco, autor);
                        } else {
                            System.out.print("Tipo (mesa/cartas/console): ");
                            String categoria = userInputs.nextLine();
                            catalogo[produtosCadastrados++] = new Jogos(nome, codigo, preco, categoria);
                        }
                        System.out.println("Produto cadastrado!");
                    } else {
                        System.out.println("Catálogo cheio!");
                    }
                    break;

                case 2:
                    for (int i = 0; i < produtosCadastrados; i++) {
                        catalogo[i].exibirDetalhes();
                    }
                    break;

                case 3:
                    if (clientesCadastrados < clientes.length) {
                        System.out.print("Nome: ");
                        String cliNome = userInputs.nextLine();
                        System.out.print("CPF (somente números): ");
                        double cpf = userInputs.nextDouble();
                        System.out.print("Idade: ");
                        int idade = userInputs.nextInt();
                        userInputs.nextLine();
                        System.out.print("Endereço: ");
                        String endereco = userInputs.nextLine();

                        clientes[clientesCadastrados++] = new PerfilClientes(cliNome, cpf, idade, endereco);
                        System.out.println("Cliente cadastrado!");
                    } else {
                        System.out.println("Limite de clientes atingido!");
                    }
                    break;

                case 4:
                    for (int i = 0; i < clientesCadastrados; i++) {
                        clientes[i].exibirInfo();
                    }
                    break;

                case 5:
                    Pedidos pedido = new Pedidos(5);
                    boolean adicionando = true;
                    while (adicionando) {
                        System.out.print("Digite índice do produto no catálogo (-1 para finalizar): ");
                        int idx = userInputs.nextInt();
                        if (idx == -1) {
                            adicionando = false;
                        } else if (idx >= 0 && idx < produtosCadastrados) {
                            pedido.adicionarItem(catalogo[idx]);
                            System.out.println("Item adicionado!");
                        } else {
                            System.out.println("Índice inválido!");
                        }
                    }
                    double valorFinal = pedido.fecharPedido();
                    caixa.depositar(valorFinal);
                    System.out.println("Pedido concluído. Total: R$ " + valorFinal);
                    break;

                case 6:
                    System.out.println("Saldo atual do caixa: R$ " + caixa.getSaldo());
                    break;

                case 7:
                    executando = false;
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida!");
            }
        }
        userInputs.close();
    }
}
