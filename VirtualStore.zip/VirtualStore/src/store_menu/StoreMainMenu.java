package store_menu;

import javax.swing.JOptionPane;
import store_database.ProductDatabase;
import store_cart.*;
import store_order.Order;
import store_products.*;
import store_users.User;
import java.util.ArrayList;
import java.util.List;

public class StoreMainMenu {

    private User currentUser = null;
    private Cart cart = new Cart();

    public void openMenu() {
        boolean running = true;

        while (running) {
            String[] options = {
                    "Navegar", "Crie sua conta", "Pesquisar", "Carrinho",
                    "Finalizar pedido", "Pedidos", "Excluir conta", "Sair da loja"
            };

            int choice = JOptionPane.showOptionDialog(null,
                    "Bem-vindo à Loja Virtual!\nEscolha uma opção:",
                    "Loja Virtual", JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

            switch (choice) {
                case 0:
                    viewProducts();
                    break;
                case 1:
                    registerAccount();
                    break;
                case 2:
                    searchProduct();
                    break;
                case 3:
                    viewCart();
                    break;
                case 4:
                    finishOrder();
                    break;
                case 5:
                    viewOrders();
                    break;
                case 6:
                    deleteAccount();
                    break;
                case 7:
                    running = false;
                    JOptionPane.showMessageDialog(null, "Obrigado por visitar nossa Loja!");
                    break;
                default:
                    running = false;
                    break;
            }
        }
    }


    private void viewProducts() {
        List<Product> products = ProductDatabase.getProducts();
        int page = 0;
        int pageSize = 10;
        int totalPages = (int) Math.ceil((double) products.size() / pageSize);

        boolean browsing = true;

        while (browsing) {
            int start = page * pageSize;
            int end = Math.min(start + pageSize, products.size());

            String[] productOptions = new String[end - start + 3];
            StringBuilder message = new StringBuilder("Escolha um produto para adicionar ao carrinho:\n\n");

            for (int i = start; i < end; i++) {
                Product p = products.get(i);
                String option = (i - start + 1) + ". " + p.getName() + " - " + p.getType() + " - R$" + String.format("%.2f", p.getPrice());
                productOptions[i - start] = option;
                message.append(option).append("\n");
            }

            productOptions[end - start] = "Página anterior";
            productOptions[end - start + 1] = "Próxima página";
            productOptions[end - start + 2] = "Sair";

            int choice = JOptionPane.showOptionDialog(null,
                    message.toString() + "\nPágina " + (page + 1) + " de " + totalPages,
                    "Produtos",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE,
                    null,
                    productOptions,
                    productOptions[0]);

            if (choice == -1 || choice == end - start + 2) {
                browsing = false;
            } else if (choice == end - start + 1 && page < totalPages - 1) {
                page++;
            } else if (choice == end - start && page > 0) {
                page--;
            } else if (choice >= 0 && choice < (end - start)) {
                Product selectedProduct = products.get(start + choice);
                cart.addProduct(selectedProduct);
                JOptionPane.showMessageDialog(null, selectedProduct.getName() + " foi adicionado ao carrinho.");
            }
        }
    }

    private void searchProduct() {
        List<Product> allProducts = ProductDatabase.getProducts();
        String keyword = JOptionPane.showInputDialog("Digite o nome, tipo, autor, gênero ou plataforma para buscar:");

        if (keyword == null || keyword.trim().isEmpty()) {
            return;
        }

        keyword = keyword.toLowerCase();
        List<Product> filtered = new ArrayList<>();

        for (Product p : allProducts) {
            if (p.getName().toLowerCase().contains(keyword) ||
                    p.getType().toLowerCase().contains(keyword)) {

                filtered.add(p);
                continue;
            }

            if (p instanceof Book book) {
                if (book.getAuthor().toLowerCase().contains(keyword) ||
                        book.getGenre().toLowerCase().contains(keyword)) {
                    filtered.add(book);
                }
            } else if (p instanceof Game game) {
                if (game.getGenre().toLowerCase().contains(keyword) ||
                        game.getPlatform().toLowerCase().contains(keyword)) {
                    filtered.add(game);
                }
            }
        }

        if (filtered.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum produto encontrado com esse termo.");
            return;
        }

        int page = 0;
        int pageSize = 10;
        int totalPages = (int) Math.ceil((double) filtered.size() / pageSize);
        boolean browsing = true;

        while (browsing) {
            int start = page * pageSize;
            int end = Math.min(start + pageSize, filtered.size());

            StringBuilder productPage = new StringBuilder("Resultados encontrados:\n\n");
            for (int i = start; i < end; i++) {
                Product p = filtered.get(i);
                productPage.append((i + 1)).append(". ")
                        .append(p.getName()).append(" - ")
                        .append(p.getType()).append(" - ")
                        .append("R$").append(String.format("%.2f", p.getPrice())).append("\n\n");
            }

            String[] options = {"Anterior", "Próxima", "Sair"};
            int option = JOptionPane.showOptionDialog(null, productPage.toString(),
                    "Página " + (page + 1) + " de " + totalPages,
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE,
                    null, options, options[2]);

            if (option == 0 && page > 0) {
                page--;
            } else if (option == 1 && page < totalPages - 1) {
                page++;
            } else {
                browsing = false;
            }
        }
    }

    private void registerAccount() {
        UserRegisterMenu registerMenu = new UserRegisterMenu();
        currentUser = registerMenu.registerUser();
    }

    private void viewCart() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(null, "Crie sua conta para acessar ao carrinho.");
            return;
        }
        JOptionPane.showMessageDialog(null, "Essa opção ainda não está disponível.");
    }

    private void finishOrder() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(null, "Crie sua conta para finalizar o pedido.");
            return;
        }

        if (cart.getItems().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Seu carrinho está vazio.");
            return;
        }

        List<Product> cartItems = new ArrayList<>(cart.getItems());
        double total = cart.getTotalPrice();

        Order newOrder = new Order(cartItems, total);
        currentUser.addOrder(newOrder);
        cart.clear();

        JOptionPane.showMessageDialog(null, "Pedido finalizado com sucesso!\n\n" + newOrder.getOrderSummary());
    }

    private void viewOrders() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(null, "Você precisa criar uma conta primeiro.");
            return;
        }

        List<Order> orders = currentUser.getOrderHistory();

        if (orders.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Você ainda não fez nenhum pedido.");
            return;
        }

        StringBuilder sb = new StringBuilder("Seus pedidos:\n\n");
        for (int i = 0; i < orders.size(); i++) {
            Order o = orders.get(i);
            sb.append(i + 1).append(". Pedido #").append(o.getOrderId())
                    .append(" - ").append(o.getDate())
                    .append(" - Status: ").append(o.getStatus()).append("\n");
        }
        sb.append("\nDigite o número do pedido que deseja gerenciar, ou 's' para sair.");

        String input = JOptionPane.showInputDialog(null, sb.toString(), "Pedidos", JOptionPane.PLAIN_MESSAGE);

        if (input == null || input.equalsIgnoreCase("s")) {
            return;
        }

        int selectedIndex = -1;
        try {
            selectedIndex = Integer.parseInt(input) - 1;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Entrada inválida.");
            return;
        }

        if (selectedIndex < 0 || selectedIndex >= orders.size()) {
            JOptionPane.showMessageDialog(null, "Número de pedido inválido.");
            return;
        }

        Order selectedOrder = orders.get(selectedIndex);

        String[] statusOptions = { "ENVIADO", "RECEBIDO", "CANCELADO", "Voltar" };
        int statusChoice = JOptionPane.showOptionDialog(null,
                "Pedido #" + selectedOrder.getOrderId() + "\nStatus atual: " + selectedOrder.getStatus() +
                        "\nEscolha o novo status:",
                "Atualizar Status",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                null,
                statusOptions,
                statusOptions[0]);

        if (statusChoice == 0) {
            selectedOrder.setStatus(Order.Status.Enviado);
            JOptionPane.showMessageDialog(null, "Status atualizado para ENVIADO.");
        } else if (statusChoice == 1) {
            selectedOrder.setStatus(Order.Status.Recebido);
            JOptionPane.showMessageDialog(null, "Status atualizado para RECEBIDO.");
        } else if (statusChoice == 2) {
            selectedOrder.setStatus(Order.Status.Cancelado);
            JOptionPane.showMessageDialog(null, "Status atualizado para CANCELADO.\nO valor será devolvido em até 30 dias.");
        }
    }

    private void deleteAccount() {
        if (currentUser == null) {
            JOptionPane.showMessageDialog(null, "Nenhuma conta ativa para excluir.");
            return;
        }

        List<Order> history = currentUser.getOrderHistory();

        if (history.isEmpty()) {
            currentUser = null;
            JOptionPane.showMessageDialog(null, "Conta excluída com sucesso.");
            return;
        }

        boolean hasPendingOrSent = false;
        boolean hasCanceled = false;

        for (Order order : history) {
            String status = order.getStatus().toString();
            if (status.equals("Pendente") || status.equals("Enviado")) {
                hasPendingOrSent = true;
                break;
            } else if (status.equals("Cancelado")) {
                hasCanceled = true;
            }
        }

        if (hasPendingOrSent) {
            JOptionPane.showMessageDialog(null,
                    "Você não pode excluir sua conta ainda, porque há pedidos pendentes ou em envio.\n" +
                            "Espere a chegada dos seus pedidos ou cancele-os para excluir a conta.");
            return;
        }
        else if (hasCanceled) {
            JOptionPane.showMessageDialog(null,
                    "Conta excluída. Seu dinheiro será devolvido em até 30 dias.");
        }
        else {
            JOptionPane.showMessageDialog(null, "Conta excluída com sucesso.");
        }

        currentUser = null;
    }
}
