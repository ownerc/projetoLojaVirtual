package store_menu;

import javax.swing.JOptionPane;
import store_users.*;
import store_payment.*;

public class UserRegisterMenu {

    public User registerUser() {
        String name = JOptionPane.showInputDialog("Nome completo:");
        String state = JOptionPane.showInputDialog("Estado:");
        String city = JOptionPane.showInputDialog("Cidade:");
        String neighborhood = JOptionPane.showInputDialog("Bairro:");
        String street = JOptionPane.showInputDialog("Rua:");
        String birthDate = JOptionPane.showInputDialog("Data de nascimento (DD/MM/AAAA):");
        String cpf = JOptionPane.showInputDialog("CPF:");
        String phone = JOptionPane.showInputDialog("Número de celular:");

        Address address = new Address(state, city, neighborhood, street);

        boolean isMinor = isMinorByYear(birthDate);
        Responsible responsible = null;

        if (isMinor) {
            JOptionPane.showMessageDialog(null, "Você é menor de idade. Será necessário adicionar os dados de um responsável.");
            String rName = JOptionPane.showInputDialog("Nome completo do responsável:");
            String rCpf = JOptionPane.showInputDialog("CPF do responsável:");
            String rPhone = JOptionPane.showInputDialog("Número de celular do responsável:");
            String rBirth = JOptionPane.showInputDialog("Data de nascimento do responsável:");
            responsible = new Responsible(rName, rCpf, rPhone, rBirth);
        }

        String[] options = {"Cartão", "Pix"};
        int paymentOption = JOptionPane.showOptionDialog(null, "Escolha sua forma de pagamento:", "Pagamento",
                JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        PaymentMethod paymentMethod;

        if (paymentOption == 0) {
            String cardNumber = JOptionPane.showInputDialog("Insira o número do cartão:");
            String[] cardTypes = {"Crédito", "Débito"};
            int cardTypeOption = JOptionPane.showOptionDialog(null, "Tipo de cartão:", "Cartão",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, cardTypes, cardTypes[0]);
            String cardType = (cardTypeOption == 0) ? "Crédito" : "Débito";
            paymentMethod = new CardPayment(cardNumber, cardType);
        } else {
            paymentMethod = new PixPayment();
        }

        User user = new User(name, address, birthDate, cpf, phone, paymentMethod);

        if (responsible != null) {
            user.setResponsible(responsible);
        }

        JOptionPane.showMessageDialog(null, "Conta criada com sucesso! Bem-vindo à loja.");
        return user;
    }

    private boolean isMinorByYear(String birthDate) {
        try {
            String[] parts = birthDate.split("/");
            int birthYear = Integer.parseInt(parts[2]);
            return birthYear > 2006;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Data inválida. Considerando maior de idade.");
            return false;
        }
    }
}
