package caixa;

public class Caixa {
    private double saldo;

    public Caixa() {
        saldo = 0.0;
    }

    public void depositar(double valor) {
        saldo += valor;
    }

    public double getSaldo() {
        return saldo;
    }
}