package produtos;

public class Livros implements Produtos {
    private String nome;
    private String codigo;
    private double preco;
    private String autor;

    public Livros(String nome, String codigo, double preco, String autor) {
        this.nome = nome;
        this.codigo = codigo;
        this.preco = preco;
        this.autor = autor;
    }

    @Override
    public void nome() {
        System.out.println("Nome do livro: " + nome);
    }

    @Override
    public void codigo() {
        System.out.println("Código do livro: " + codigo);
    }

    @Override
    public void preco() {
        System.out.println("Preço do livro: R$ " + preco);
    }

    @Override
    public void exibirDetalhes() {
        System.out.println("Detalhes do Livro: ");
        nome();
        codigo();
        preco();
        System.out.println("Autor: " + autor);
    }
}
