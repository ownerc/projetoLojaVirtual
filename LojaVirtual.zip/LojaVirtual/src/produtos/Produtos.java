package produtos;

public interface Produtos {
    void nome();
    void codigo();
    void preco();
    void exibirDetalhes();

}
