package clientes;

public abstract class Clientes {
    protected String clienteNome;
    protected double clienteCpf;
    protected int idade;
    protected String endereco;

    public Clientes(String clienteNome, double clienteCpf, int idade, String endereco) {
        this.clienteNome = clienteNome;
        this.clienteCpf = clienteCpf;
        this.idade = idade;
        this.endereco = endereco;
    }

    public abstract void exibirInfo();
}
