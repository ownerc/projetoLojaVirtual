package clientes;

public class PerfilClientes extends Clientes {
    public PerfilClientes(String clienteNome, double clienteCpf, int idade, String endereco) {
        super(clienteNome, clienteCpf, idade, endereco);
    }

    @Override
    public String toString() {
        return "Nome: " + clienteNome + ", CPF: " + clienteCpf + ", Idade: " + idade + ", Endereço: " + endereco;
    }

    @Override
    public void exibirInfo() {
        System.out.println(clienteNome + "\n");
        System.out.println("CPF: " + clienteCpf);
        System.out.println("Idade: " + idade);
        System.out.println("Endereço: " + endereco);
    }
}
