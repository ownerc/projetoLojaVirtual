import javax.swing.JOptionPane;
import produtos.*;
import clientes.*;
import caixa.Caixa;

public class Main {
    public static void main(String[] args) {
        Caixa caixa = new Caixa();

        Produtos[] carrinho = new Produtos[10];
        int produtosCadastrados = 0;

        Clientes[] clientes = new Clientes[1];
        int clientesCadastrados = 0;


        while (true) {
            String menu = """
                    LOJA VIRTUAL
                    1 - Adicionar ao carrinho
                    2 - Ver carrinho
                    3 - Criar conta
                    4 - Perfil
                    5 - Fechar pedido
                    6 - Saldo
                    7 - Sair
                    Escolha uma opção:
                    """;

            int opcao = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcao) {
                case 1 -> {
                    if (produtosCadastrados < carrinho.length) {
                        String tipo = JOptionPane.showInputDialog("O produto que você escolheu é um Livro ou Jogo (L/J)?");
                        String nome = JOptionPane.showInputDialog("Nome:");
                        String codigo = JOptionPane.showInputDialog("Código:");
                        double preco = Double.parseDouble(JOptionPane.showInputDialog("Preço:"));

                        if (tipo.equalsIgnoreCase("L")) {
                            String autor = JOptionPane.showInputDialog("Autor:");
                            carrinho[produtosCadastrados++] = new Livros(nome, codigo, preco, autor);
                        } else {
                            String categoria = JOptionPane.showInputDialog("Defina o tipo de jogo (mesa/cartas/console):");
                            carrinho[produtosCadastrados++] = new Jogos(nome, codigo, preco, categoria);
                        }
                        JOptionPane.showMessageDialog(null, "Produto no carrinho!");
                    } else {
                        JOptionPane.showMessageDialog(null, "Seu carrinho está cheio!");
                    }
                }

                case 2 -> {
                    if (produtosCadastrados == 0) {
                        JOptionPane.showMessageDialog(null, "Nenhum produto cadastrado.");
                    } else {
                        StringBuilder lista = new StringBuilder("Produtos:\n");
                        for (int i = 0; i < produtosCadastrados; i++) {
                            lista.append(i).append(" - ").append(carrinho[i].toString()).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, lista.toString());
                    }
                }

                case 3 -> {
                    if (clientesCadastrados < clientes.length) {
                        String clienteNome = JOptionPane.showInputDialog("Nome:");
                        String stringCpf = JOptionPane.showInputDialog("CPF (somente números):");
                        String stringIdade = JOptionPane.showInputDialog("Idade:");
                        String endereco = JOptionPane.showInputDialog("Endereço:");

                        if (clienteNome != null && !clienteNome.isEmpty()
                                && stringCpf != null && stringCpf.matches("\\d+")
                                && stringIdade != null && stringIdade.matches("\\d+")
                                && endereco != null && !endereco.isEmpty()) {

                            double cpf = Double.parseDouble(stringCpf);
                            int idade = Integer.parseInt(stringIdade);

                            if (cpf > 0 && idade >= 0 && idade <= 100) {
                                clientes[clientesCadastrados++] = new PerfilClientes(clienteNome, cpf, idade, endereco);
                                JOptionPane.showMessageDialog(null, "Cliente cadastrado!");
                            } else {
                                JOptionPane.showMessageDialog(null, "CPF deve ser maior que 0 e idade entre 0 e 100.");
                            }
                        } else {
                            JOptionPane.showMessageDialog(null, "Por favor, preencha todos os dados corretamente.");
                        }
                    } else {
                        JOptionPane.showMessageDialog(null, "Você já possui uma conta!");
                    }
                }

                    case 4 -> {
                    if (clientesCadastrados == 0) {
                        JOptionPane.showMessageDialog(null, "Nenhum cliente cadastrado.");
                    } else {
                        StringBuilder lista = new StringBuilder("Clientes:\n");
                        for (int i = 0; i < clientesCadastrados; i++) {
                            lista.append(clientes[i].toString()).append("\n");
                        }
                        JOptionPane.showMessageDialog(null, lista.toString());
                    }
                }

                case 5 -> {
                    Pedidos pedido = new Pedidos(5);

                    while (true) {
                        String input = JOptionPane.showInputDialog("Código do produto:");
                        int fecharPedido = Integer.parseInt(JOptionPane.showInputDialog("Digite -1 para finalizar sua compra:"));
                        if (fecharPedido == -1) {
                            break;
                        } else if (fecharPedido >= 0 && fecharPedido < produtosCadastrados) {
                            pedido.adicionarItem(carrinho[fecharPedido]);
                            JOptionPane.showMessageDialog(null, "Item adicionado!");
                        } else {
                            JOptionPane.showMessageDialog(null, "Índice inválido!");
                        }
                    }

                    double valorFinal = pedido.fecharPedido();
                    caixa.depositar(valorFinal);
                    JOptionPane.showMessageDialog(null, "Pedido concluído. Total: R$ " + valorFinal);
                }

                case 6 -> JOptionPane.showMessageDialog(null, "Saldo atual do caixa: R$ " + caixa.getSaldo());

                case 7 -> {
                    JOptionPane.showMessageDialog(null, "Saindo...");
                    break;
                }

                default -> JOptionPane.showMessageDialog(null, "Opção inválida!");
            }
        }
    }
}
